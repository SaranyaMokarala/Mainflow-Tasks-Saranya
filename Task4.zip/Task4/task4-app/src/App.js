import React, { useState } from 'react';

function App() {
  const [tasks, setTasks] = useState([]);
  const [taskName, setTaskName] = useState('');
  const [taskNo, setTaskNo] = useState(0);

  const addTask = () => {
    if (taskName.trim() === '') return;

    setTaskNo(prevTaskNo => prevTaskNo + 1);
    setTasks(prevTasks => [
      ...prevTasks,
      { id: taskNo + 1, name: taskName, status: 'Processing' }
    ]);
    setTaskName('');
  };

  const completeTask = id => {
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === id ? { ...task, status: 'Completed' } : task
      )
    );
  };

  const deleteTask = id => {
    setTasks(prevTasks => prevTasks.filter(task => task.id !== id));
  };

  return (
    <div className="text-center font-sans">
      <h1 className="bg-lavender shadow-md p-2">Task Manager</h1>
      <p className="font-bold text-xl">Task Name :</p>
      <input
        type="text"
        id="taskName"
        value={taskName}
        onChange={(e) => setTaskName(e.target.value)}
        className="p-2 w-64 shadow-md border-none"
      />
      <button
        id="addTaskButton"
        onClick={addTask}
        className="p-2 w-24 bg-blue-200 font-bold shadow-md transition-all duration-500 ease-in-out hover:shadow-none"
      >
        Add Task
      </button>
      <center>
        <table id="task-list" className="m-10 bg-azure p-2 font-bold text-black shadow-lg">
          <tbody>
            {tasks.map(task => (
              <tr key={task.id} id={task.id.toString()}>
                <td id={`t${task.id}`}>{task.name}</td>
                <td>{task.status}</td>
                <td>
                  {task.status === 'Processing' && (
                    <button
                      onClick={() => completeTask(task.id)}
                      className="p-2 bg-blue-200 font-bold shadow-md transition-all duration-500 ease-in-out hover:shadow-none"
                    >
                      Complete Task
                    </button>
                  )}
                </td>
                <td>
                  <button
                    onClick={() => deleteTask(task.id)}
                    className="p-2 bg-blue-200 font-bold shadow-md transition-all duration-500 ease-in-out hover:shadow-none"
                  >
                    Delete Task
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </center>
    </div>
  );
}

export default App;